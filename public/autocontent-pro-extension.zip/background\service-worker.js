"use strict";
(() => {
  // background/service-worker.ts
  chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === "install") {
      console.log("[AutoContent Pro] \u63D2\u4EF6\u5DF2\u5B89\u88C5\uFF0C\u8BF7\u5728\u8BBE\u7F6E\u4E2D\u914D\u7F6E API Key");
    } else if (details.reason === "update") {
      console.log("[AutoContent Pro] \u63D2\u4EF6\u5DF2\u66F4\u65B0\u81F3", chrome.runtime.getManifest().version);
    }
  });
  chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {
      const msg = message;
      if (msg.type === "CONTENT_EXTRACTED") {
        chrome.runtime.sendMessage(message).catch(() => {
        });
      }
      sendResponse({ received: true });
      return true;
    }
  );
})();
