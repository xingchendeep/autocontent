/**
 * 知乎文章内容提取器
 * 目标选择器：.Post-RichTextContainer 或 .RichText
 */
export function extractZhihu() {
    const el = document.querySelector('.Post-RichTextContainer') ??
        document.querySelector('.RichText');
    if (!el)
        return '';
    return el.innerText.trim();
}
