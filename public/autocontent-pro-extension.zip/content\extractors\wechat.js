/**
 * 微信公众号文章内容提取器
 * 目标选择器：#js_content
 */
export function extractWechat() {
    const el = document.querySelector('#js_content');
    if (!el)
        return '';
    return el.innerText.trim();
}
