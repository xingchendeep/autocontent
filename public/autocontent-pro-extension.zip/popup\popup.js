"use strict";
(() => {
  // utils/storage.ts
  var API_KEY_STORAGE_KEY = "acp_api_key";
  async function getApiKey() {
    const result = await chrome.storage.local.get(API_KEY_STORAGE_KEY);
    return result[API_KEY_STORAGE_KEY] ?? null;
  }
  async function setApiKey(key) {
    await chrome.storage.local.set({ [API_KEY_STORAGE_KEY]: key });
  }
  async function clearApiKey() {
    await chrome.storage.local.remove(API_KEY_STORAGE_KEY);
  }

  // utils/api.ts
  var APP_URL = "https://www.help-online.cn";
  async function extractVideoScript(videoUrl, audioUrl, awemeId) {
    const apiKey = await getApiKey();
    if (!apiKey) throw new Error("\u8BF7\u5148\u5728\u63D2\u4EF6\u8BBE\u7F6E\u4E2D\u914D\u7F6E API Key");
    let res;
    try {
      const body = { videoUrl };
      if (audioUrl) body.audioUrl = audioUrl;
      if (awemeId) body.awemeId = awemeId;
      res = await fetch(`${APP_URL}/api/extract`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`
        },
        body: JSON.stringify(body)
      });
    } catch {
      throw new Error("\u7F51\u7EDC\u8FDE\u63A5\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u8BD5");
    }
    if (res.status === 401) throw new Error("API Key \u65E0\u6548\u6216\u5DF2\u8FC7\u671F");
    if (res.status === 429) throw new Error("\u4ECA\u65E5\u63D0\u53D6\u6B21\u6570\u5DF2\u7528\u5B8C\uFF0C\u8BF7\u660E\u5929\u518D\u8BD5\u6216\u5347\u7EA7\u5957\u9910");
    if (!res.ok) throw new Error(`\u63D0\u53D6\u5931\u8D25\uFF08${res.status}\uFF09`);
    const json = await res.json();
    return json.data;
  }
  async function getExtractJobStatus(jobId) {
    const apiKey = await getApiKey();
    if (!apiKey) throw new Error("\u8BF7\u5148\u914D\u7F6E API Key");
    const res = await fetch(`${APP_URL}/api/extract/${jobId}`, {
      headers: { Authorization: `Bearer ${apiKey}` }
    });
    if (!res.ok) throw new Error(`\u67E5\u8BE2\u5931\u8D25\uFF08${res.status}\uFF09`);
    const json = await res.json();
    return json.data;
  }
  async function waitForExtraction(jobId, maxAttempts = 40) {
    for (let i = 0; i < maxAttempts; i++) {
      await new Promise((r) => setTimeout(r, 3e3));
      const job = await getExtractJobStatus(jobId);
      if (job.status === "completed" || job.status === "failed") return job;
    }
    throw new Error("\u63D0\u53D6\u8D85\u65F6\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
  }
  async function generate(req) {
    const apiKey = await getApiKey();
    if (!apiKey) {
      throw new Error("\u8BF7\u5148\u5728\u63D2\u4EF6\u8BBE\u7F6E\u4E2D\u914D\u7F6E API Key");
    }
    let res;
    try {
      res = await fetch(`${APP_URL}/api/v1/generate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`
        },
        body: JSON.stringify(req)
      });
    } catch {
      throw new Error("\u7F51\u7EDC\u8FDE\u63A5\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u8BD5");
    }
    if (res.status === 401) {
      throw new Error("API Key \u65E0\u6548\u6216\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u91CD\u65B0\u914D\u7F6E");
    }
    if (res.status === 429) {
      throw new Error("\u8BF7\u6C42\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5");
    }
    if (res.status === 402) {
      throw new Error("\u5F53\u524D\u5957\u9910\u4E0D\u652F\u6301\u6B64\u64CD\u4F5C\uFF0C\u8BF7\u5347\u7EA7\u5957\u9910");
    }
    if (!res.ok) {
      throw new Error(`\u751F\u6210\u5931\u8D25\uFF08${res.status}\uFF09\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5`);
    }
    const json = await res.json();
    return json.data;
  }

  // popup/popup.ts
  var PLATFORM_NAMES = {
    douyin: "\u6296\u97F3",
    xiaohongshu: "\u5C0F\u7EA2\u4E66",
    bilibili: "\u54D4\u54E9\u54D4\u54E9",
    weibo: "\u5FAE\u535A",
    wechat: "\u5FAE\u4FE1\u516C\u4F17\u53F7",
    twitter: "Twitter/X",
    linkedin: "LinkedIn",
    kuaishou: "\u5FEB\u624B",
    zhihu: "\u77E5\u4E4E",
    toutiao: "\u4ECA\u65E5\u5934\u6761"
  };
  var extractedContent = "";
  var contentValid = false;
  var btnGenerate = document.getElementById("btn-generate");
  var btnSettings = document.getElementById("btn-settings");
  var btnSaveKey = document.getElementById("btn-save-key");
  var btnClearKey = document.getElementById("btn-clear-key");
  var sectionSettings = document.getElementById("section-settings");
  var sectionResults = document.getElementById("section-results");
  var contentPreview = document.getElementById("content-preview");
  var contentActions = document.getElementById("content-actions");
  var btnToggleContent = document.getElementById("btn-toggle-content");
  var btnCopyContent = document.getElementById("btn-copy-content");
  var errorMsg = document.getElementById("error-msg");
  var resultsList = document.getElementById("results-list");
  var inputApiKey = document.getElementById("input-apikey");
  var btnExtractScript = document.getElementById("btn-extract-script");
  var extractStatus = document.getElementById("extract-status");
  var currentTabUrl = "";
  var currentTabId;
  btnSettings.addEventListener("click", () => {
    sectionSettings.classList.toggle("hidden");
  });
  btnSaveKey.addEventListener("click", async () => {
    const key = inputApiKey.value.trim();
    if (key) {
      await setApiKey(key);
      inputApiKey.value = "";
      sectionSettings.classList.add("hidden");
    }
  });
  btnClearKey.addEventListener("click", async () => {
    await clearApiKey();
    inputApiKey.value = "";
  });
  getApiKey().then((key) => {
    if (key) inputApiKey.value = key;
  });
  var contentExpanded = false;
  btnToggleContent.addEventListener("click", () => {
    contentExpanded = !contentExpanded;
    if (contentExpanded) {
      contentPreview.textContent = extractedContent;
      contentPreview.classList.add("expanded");
      btnToggleContent.textContent = "\u6536\u8D77";
    } else {
      contentPreview.textContent = extractedContent.slice(0, 120) + (extractedContent.length > 120 ? "..." : "");
      contentPreview.classList.remove("expanded");
      btnToggleContent.textContent = "\u5C55\u5F00\u5168\u6587";
    }
  });
  btnCopyContent.addEventListener("click", async () => {
    await navigator.clipboard.writeText(extractedContent);
    btnCopyContent.textContent = "\u5DF2\u590D\u5236";
    setTimeout(() => {
      btnCopyContent.textContent = "\u590D\u5236\u5185\u5BB9";
    }, 1500);
  });
  btnExtractScript.addEventListener("click", async () => {
    if (!currentTabUrl) {
      showExtractStatus("\u65E0\u6CD5\u83B7\u53D6\u5F53\u524D\u9875\u9762 URL", "error");
      return;
    }
    btnExtractScript.disabled = true;
    btnExtractScript.textContent = "\u23F3 \u63D0\u53D6\u4E2D...";
    try {
      if (currentTabUrl.includes("bilibili.com") && currentTabId) {
        showExtractStatus("\u6B63\u5728\u4ECE B\u7AD9\u63D0\u53D6\u5B57\u5E55...", "loading");
        const [{ result: subResult }] = await chrome.scripting.executeScript({
          target: { tabId: currentTabId },
          func: async () => {
            try {
              const bvMatch = window.location.href.match(/\/video\/(BV[\w]+)/i);
              const bvid = bvMatch ? bvMatch[1] : null;
              if (!bvid) return { ok: false, error: "\u65E0\u6CD5\u8BC6\u522B B\u7AD9\u89C6\u9891 ID" };
              const viewRes = await fetch(
                `https://api.bilibili.com/x/web-interface/view?bvid=${bvid}`,
                { credentials: "include" }
              );
              const viewJson = await viewRes.json();
              const cid = viewJson?.data?.cid;
              if (!cid) return { ok: false, error: "\u65E0\u6CD5\u83B7\u53D6\u89C6\u9891\u4FE1\u606F" };
              const playerRes = await fetch(
                `https://api.bilibili.com/x/player/v2?bvid=${bvid}&cid=${cid}`,
                { credentials: "include" }
              );
              const playerJson = await playerRes.json();
              const subtitles = playerJson?.data?.subtitle?.subtitles;
              if (!subtitles || subtitles.length === 0) {
                return { ok: false, error: "\u8BE5\u89C6\u9891\u6CA1\u6709\u5B57\u5E55" };
              }
              const zhSub = subtitles.find((s) => s.lan.startsWith("zh")) ?? subtitles[0];
              let subUrl = zhSub.subtitle_url;
              if (subUrl.startsWith("//")) subUrl = "https:" + subUrl;
              const subRes = await fetch(subUrl);
              const subJson = await subRes.json();
              if (!subJson?.body?.length) return { ok: false, error: "\u5B57\u5E55\u5185\u5BB9\u4E3A\u7A7A" };
              const items = subJson.body;
              const parts = [];
              for (let i = 0; i < items.length; i++) {
                const s = items[i].content.trim();
                if (!s) continue;
                if (/[。！？.!?]$/.test(s)) {
                  parts.push(s);
                  continue;
                }
                if (/[，,；;：:、…—]$/.test(s)) {
                  parts.push(s);
                  continue;
                }
                if (i === items.length - 1) {
                  parts.push(s + "\u3002");
                  continue;
                }
                const gap = items[i + 1].from - items[i].to;
                if (gap >= 0.5) {
                  parts.push(s + "\u3002");
                } else {
                  parts.push(s + "\uFF0C");
                }
              }
              const text = parts.join("");
              return { ok: true, text, lang: zhSub.lan };
            } catch (e) {
              return { ok: false, error: String(e) };
            }
          }
        });
        const sub = subResult;
        if (sub?.ok && sub.text) {
          extractedContent = sub.text;
          contentValid = true;
          contentPreview.textContent = extractedContent.slice(0, 120) + (extractedContent.length > 120 ? "..." : "");
          contentPreview.classList.remove("invalid");
          btnGenerate.disabled = false;
          contentExpanded = false;
          btnToggleContent.textContent = "\u5C55\u5F00\u5168\u6587";
          showExtractStatus(`\u2705 B\u7AD9\u5B57\u5E55\u63D0\u53D6\u6210\u529F\uFF08${sub.lang ?? "zh"}\uFF09\uFF0C\u53EF\u4EE5\u751F\u6210\u6587\u6848\u4E86`, "success");
        } else {
          showExtractStatus(`\u274C ${sub?.error ?? "\u5B57\u5E55\u63D0\u53D6\u5931\u8D25\uFF0C\u8BE5\u89C6\u9891\u53EF\u80FD\u6CA1\u6709\u5B57\u5E55"}`, "error");
        }
      } else if (currentTabUrl.includes("douyin.com") && currentTabId) {
        showExtractStatus("\u6B63\u5728\u4ECE\u6296\u97F3\u63D0\u53D6\u89C6\u9891\u5730\u5740...", "loading");
        const [{ result: dyResult }] = await chrome.scripting.executeScript({
          target: { tabId: currentTabId },
          func: () => {
            try {
              const cleanUrl = (u) => u.replace(/\\u002F/g, "/").replace(/\\/g, "");
              const VIDEO_CDN_PATTERNS = /(?:douyinvod|v\d+-[a-z]+\.douyinvod|bytevcloudcdn|bytecdn|amemv)/i;
              const NON_VIDEO_PATTERNS = /\.(png|jpg|jpeg|gif|webp|svg|ico|css|js|woff|ttf)(\?|$)/i;
              const isVideoUrl = (u) => {
                if (NON_VIDEO_PATTERNS.test(u)) return false;
                if (VIDEO_CDN_PATTERNS.test(u)) return true;
                if (/\.mp4(\?|$)/i.test(u)) return true;
                return false;
              };
              const videoUrls = [];
              const addVideoUrl = (u) => {
                const clean = cleanUrl(u);
                if (clean.startsWith("http") && isVideoUrl(clean) && !videoUrls.includes(clean)) {
                  videoUrls.push(clean);
                }
              };
              let awemeId = "";
              const url = window.location.href;
              const videoMatch = url.match(/\/video\/(\d+)/);
              const modalMatch = url.match(/modal_id=(\d+)/);
              awemeId = videoMatch?.[1] ?? modalMatch?.[1] ?? "";
              const renderScript = document.querySelector("#RENDER_DATA");
              if (renderScript?.textContent) {
                try {
                  const decoded = decodeURIComponent(renderScript.textContent);
                  const data = JSON.parse(decoded);
                  if (!awemeId) {
                    const visited = /* @__PURE__ */ new WeakSet();
                    const findId = (obj, depth) => {
                      if (awemeId || depth > 10 || !obj || typeof obj !== "object") return;
                      const o = obj;
                      if (visited.has(o)) return;
                      visited.add(o);
                      if (typeof o.aweme_id === "string" && /^\d+$/.test(o.aweme_id)) {
                        awemeId = o.aweme_id;
                        return;
                      }
                      for (const v of Object.values(o)) {
                        if (v && typeof v === "object") {
                          if (Array.isArray(v)) {
                            for (const item of v) findId(item, depth + 1);
                          } else {
                            findId(v, depth + 1);
                          }
                        }
                      }
                    };
                    findId(data, 0);
                  }
                  const visited2 = /* @__PURE__ */ new WeakSet();
                  const traverse = (obj, depth) => {
                    if (depth > 20 || !obj || typeof obj !== "object") return;
                    const o = obj;
                    if (visited2.has(o)) return;
                    visited2.add(o);
                    if (Array.isArray(o.url_list)) {
                      for (const u of o.url_list) {
                        if (typeof u === "string") addVideoUrl(u);
                      }
                    }
                    for (const v of Object.values(o)) {
                      if (v && typeof v === "object") {
                        if (Array.isArray(v)) {
                          for (const item of v) {
                            if (item && typeof item === "object") traverse(item, depth + 1);
                          }
                        } else {
                          traverse(v, depth + 1);
                        }
                      }
                    }
                  };
                  traverse(data, 0);
                  if (videoUrls.length === 0) {
                    const pat = /https?:\/\/[^"'\s]+?(?:douyinvod|bytevcloudcdn|bytecdn|amemv)[^"'\s]*/gi;
                    const matches = decoded.match(pat);
                    if (matches) for (const m of matches) addVideoUrl(m);
                  }
                } catch {
                }
              }
              for (const el of Array.from(document.querySelectorAll("video, xg-video"))) {
                const src = el.getAttribute("src") || el.currentSrc;
                if (src) {
                  const clean = cleanUrl(src);
                  if (clean.startsWith("http") && !NON_VIDEO_PATTERNS.test(clean) && !videoUrls.includes(clean)) {
                    videoUrls.push(clean);
                  }
                }
              }
              const best = videoUrls.find((u) => /\.mp4(\?|$)/i.test(u)) ?? videoUrls[0];
              if (!best && !awemeId) {
                return { ok: false, error: "\u65E0\u6CD5\u4ECE\u6296\u97F3\u9875\u9762\u63D0\u53D6\u89C6\u9891\u5730\u5740\uFF0C\u8BF7\u786E\u4FDD\u5DF2\u6253\u5F00\u89C6\u9891\u64AD\u653E\u9875" };
              }
              return {
                ok: true,
                videoUrl: best ?? "",
                awemeId,
                debug: `urls=${videoUrls.length}, awemeId=${awemeId || "none"}`
              };
            } catch (e) {
              return { ok: false, error: String(e) };
            }
          }
        });
        const dy = dyResult;
        if (dy?.ok && (dy.videoUrl || dy.awemeId)) {
          showExtractStatus(`\u5DF2\u83B7\u53D6\u89C6\u9891\u4FE1\u606F\uFF08${dy.debug ?? ""}\uFF09\uFF0C\u6B63\u5728\u63D0\u4EA4\u8BED\u97F3\u8BC6\u522B\u4EFB\u52A1...`, "loading");
          try {
            const job = await extractVideoScript(currentTabUrl, dy.videoUrl, dy.awemeId);
            showExtractStatus(`\u8BED\u97F3\u8BC6\u522B\u4EFB\u52A1\u5DF2\u63D0\u4EA4\uFF08${job.platform}\uFF09\uFF0C\u6B63\u5728\u5904\u7406...`, "loading");
            const result = await waitForExtraction(job.jobId);
            if (result.status === "completed" && result.result?.text) {
              extractedContent = result.result.text;
              contentValid = true;
              contentPreview.textContent = extractedContent.slice(0, 120) + (extractedContent.length > 120 ? "..." : "");
              contentPreview.classList.remove("invalid");
              btnGenerate.disabled = false;
              contentExpanded = false;
              btnToggleContent.textContent = "\u5C55\u5F00\u5168\u6587";
              showExtractStatus("\u2705 \u6296\u97F3\u89C6\u9891\u8BED\u97F3\u8BC6\u522B\u5B8C\u6210\uFF0C\u53EF\u4EE5\u751F\u6210\u6587\u6848\u4E86", "success");
            } else {
              showExtractStatus(`\u274C \u8BED\u97F3\u8BC6\u522B\u5931\u8D25\uFF1A${result.error ?? "\u672A\u77E5\u9519\u8BEF"}`, "error");
            }
          } catch (err) {
            showExtractStatus(`\u274C ${err.message}`, "error");
          }
        } else {
          showExtractStatus(`\u274C ${dy?.error ?? "\u6296\u97F3\u89C6\u9891\u5730\u5740\u63D0\u53D6\u5931\u8D25"}`, "error");
        }
      } else if (currentTabUrl.includes("kuaishou.com") && currentTabId) {
        showExtractStatus("\u6B63\u5728\u4ECE\u5FEB\u624B\u63D0\u53D6\u89C6\u9891\u5730\u5740...", "loading");
        const [{ result: ksResult }] = await chrome.scripting.executeScript({
          target: { tabId: currentTabId },
          func: () => {
            try {
              const urls = [];
              const addUrl = (u) => {
                if (u.startsWith("http") && !urls.includes(u)) urls.push(u);
              };
              for (const el of Array.from(document.querySelectorAll("video"))) {
                const src = el.getAttribute("src") || el.currentSrc;
                if (src) addUrl(src);
                el.querySelectorAll("source").forEach((s) => {
                  const ssrc = s.getAttribute("src");
                  if (ssrc) addUrl(ssrc);
                });
              }
              const scripts = document.querySelectorAll("script:not([src])");
              for (const script of Array.from(scripts)) {
                const text = script.textContent ?? "";
                const pat = /https?:\/\/[^"'\s\\]+?(?:txvideo\.cn|ksyun\.com|kuaishou|ksc\.com|ali-video|v\d+\.kwaicdn|photocdn)[^"'\s\\]*/gi;
                const matches = text.match(pat);
                if (matches) {
                  for (const m of matches) addUrl(m.replace(/\\/g, ""));
                }
                const playPat = /"(?:playUrl|photoUrl|srcNoMark|url)"\s*:\s*"(https?:[^"]+)"/gi;
                let match;
                while ((match = playPat.exec(text)) !== null) {
                  addUrl(match[1].replace(/\\u002F/g, "/").replace(/\\/g, ""));
                }
              }
              const ogVideo = document.querySelector('meta[property="og:video"]')?.getAttribute("content");
              if (ogVideo) addUrl(ogVideo);
              const ogVideoUrl = document.querySelector('meta[property="og:video:url"]')?.getAttribute("content");
              if (ogVideoUrl) addUrl(ogVideoUrl);
              const best = urls.find((u) => /\.mp4|mp4/i.test(u)) ?? urls[0];
              if (!best) {
                return { ok: false, error: "\u65E0\u6CD5\u4ECE\u5FEB\u624B\u9875\u9762\u63D0\u53D6\u89C6\u9891\u5730\u5740\uFF0C\u8BF7\u786E\u4FDD\u5DF2\u6253\u5F00\u89C6\u9891\u64AD\u653E\u9875" };
              }
              return { ok: true, videoUrl: best, debug: `urls=${urls.length}` };
            } catch (e) {
              return { ok: false, error: String(e) };
            }
          }
        });
        const ks = ksResult;
        if (ks?.ok && ks.videoUrl) {
          showExtractStatus(`\u5DF2\u83B7\u53D6\u89C6\u9891\u5730\u5740\uFF08${ks.debug ?? ""}\uFF09\uFF0C\u6B63\u5728\u63D0\u4EA4\u8BED\u97F3\u8BC6\u522B\u4EFB\u52A1...`, "loading");
          try {
            const job = await extractVideoScript(currentTabUrl, ks.videoUrl);
            showExtractStatus(`\u8BED\u97F3\u8BC6\u522B\u4EFB\u52A1\u5DF2\u63D0\u4EA4\uFF08${job.platform}\uFF09\uFF0C\u6B63\u5728\u5904\u7406...`, "loading");
            const result = await waitForExtraction(job.jobId);
            if (result.status === "completed" && result.result?.text) {
              extractedContent = result.result.text;
              contentValid = true;
              contentPreview.textContent = extractedContent.slice(0, 120) + (extractedContent.length > 120 ? "..." : "");
              contentPreview.classList.remove("invalid");
              btnGenerate.disabled = false;
              contentExpanded = false;
              btnToggleContent.textContent = "\u5C55\u5F00\u5168\u6587";
              showExtractStatus("\u2705 \u5FEB\u624B\u89C6\u9891\u8BED\u97F3\u8BC6\u522B\u5B8C\u6210\uFF0C\u53EF\u4EE5\u751F\u6210\u6587\u6848\u4E86", "success");
            } else {
              showExtractStatus(`\u274C \u8BED\u97F3\u8BC6\u522B\u5931\u8D25\uFF1A${result.error ?? "\u672A\u77E5\u9519\u8BEF"}`, "error");
            }
          } catch (err) {
            showExtractStatus(`\u274C ${err.message}`, "error");
          }
        } else {
          showExtractStatus(`\u274C ${ks?.error ?? "\u5FEB\u624B\u89C6\u9891\u5730\u5740\u63D0\u53D6\u5931\u8D25"}`, "error");
        }
      } else if ((currentTabUrl.includes("ixigua.com") || currentTabUrl.includes("toutiao.com")) && currentTabId) {
        const platformName = currentTabUrl.includes("toutiao.com") ? "\u4ECA\u65E5\u5934\u6761" : "\u897F\u74DC\u89C6\u9891";
        showExtractStatus(`\u26A0\uFE0F ${platformName}\u89C6\u9891\u811A\u672C\u63D0\u53D6\u529F\u80FD\u5C06\u5728\u4E0B\u4E2A\u7248\u672C\u652F\u6301\uFF0C\u656C\u8BF7\u671F\u5F85`, "error");
      } else {
        showExtractStatus("\u6B63\u5728\u63D0\u4EA4\u89C6\u9891\u811A\u672C\u63D0\u53D6\u4EFB\u52A1...", "loading");
        const job = await extractVideoScript(currentTabUrl);
        showExtractStatus(`\u4EFB\u52A1\u5DF2\u63D0\u4EA4\uFF0C\u6B63\u5728\u63D0\u53D6\uFF08${job.platform}\uFF09...`, "loading");
        const result = await waitForExtraction(job.jobId);
        if (result.status === "completed" && result.result?.text) {
          extractedContent = result.result.text;
          contentValid = true;
          contentPreview.textContent = extractedContent.slice(0, 120) + (extractedContent.length > 120 ? "..." : "");
          contentPreview.classList.remove("invalid");
          btnGenerate.disabled = false;
          contentExpanded = false;
          btnToggleContent.textContent = "\u5C55\u5F00\u5168\u6587";
          const method = result.result.method === "subtitle_api" ? "\u5B57\u5E55" : "\u8BED\u97F3\u8BC6\u522B";
          showExtractStatus(`\u2705 \u63D0\u53D6\u6210\u529F\uFF08${method}\uFF09\uFF0C\u53EF\u4EE5\u751F\u6210\u6587\u6848\u4E86`, "success");
        } else {
          showExtractStatus(`\u274C \u63D0\u53D6\u5931\u8D25\uFF1A${result.error ?? "\u672A\u77E5\u9519\u8BEF"}`, "error");
        }
      }
    } catch (err) {
      showExtractStatus(`\u274C ${err.message}`, "error");
    } finally {
      btnExtractScript.disabled = false;
      btnExtractScript.textContent = "\u{1F3AC} \u63D0\u53D6\u89C6\u9891\u811A\u672C";
    }
  });
  function showExtractStatus(msg, type) {
    extractStatus.textContent = msg;
    extractStatus.className = `extract-status ${type}`;
    extractStatus.classList.remove("hidden");
  }
  async function extractPageContent() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) {
        contentPreview.textContent = "\u65E0\u6CD5\u83B7\u53D6\u5F53\u524D\u6807\u7B7E\u9875";
        contentPreview.classList.add("invalid");
        return;
      }
      currentTabUrl = tab.url ?? "";
      currentTabId = tab.id;
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const MIN_LEN = 50;
          const url = window.location.href;
          const host = window.location.hostname;
          function textFrom(selectors) {
            for (const sel of selectors) {
              const el = document.querySelector(sel);
              const t = el?.textContent?.trim();
              if (t && t.length > 2) return t;
            }
            return "";
          }
          function meta(name) {
            const el = document.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
            return el?.getAttribute("content")?.trim() ?? "";
          }
          let title = "";
          let desc = "";
          if (host.includes("bilibili.com")) {
            title = textFrom(["h1.video-title", ".video-title", "h1"]) || document.title;
            desc = textFrom([
              ".basic-desc-info",
              ".desc-info-text",
              "#v_desc .info",
              ".video-desc .info",
              '[class*="desc"]'
            ]);
            if (!desc) desc = meta("description");
          } else if (host.includes("douyin.com")) {
            title = textFrom([
              '[data-e2e="video-desc"]',
              ".video-info-detail .title",
              "h1",
              ".title-container"
            ]) || document.title;
            desc = meta("description");
          } else if (host.includes("xiaohongshu.com")) {
            title = textFrom([
              "#detail-title",
              ".note-title",
              'h1[class*="title"]',
              "h1"
            ]) || document.title;
            const noteDesc = textFrom([
              "#detail-desc .note-text",
              "#detail-desc",
              ".note-scroller .desc",
              ".note-desc",
              ".note-text"
            ]);
            const comments = [];
            document.querySelectorAll(
              '.comment-item .content, .comment-inner .content, [class*="commentContent"], [class*="comment-text"], .note-comment .content'
            ).forEach((el) => {
              const t = el.textContent?.trim();
              if (t && t.length > 1 && comments.length < 30) comments.push(t);
            });
            const parts = [];
            if (noteDesc) parts.push(noteDesc);
            if (comments.length > 0) parts.push("\u8BC4\u8BBA\uFF1A\n" + comments.join("\n"));
            desc = parts.join("\n\n");
            if (!desc) desc = meta("description");
          } else if (host.includes("weibo.com") || host.includes("weibo.cn")) {
            title = document.title;
            desc = textFrom([
              '[class*="detail_wbtext"]',
              ".weibo-text",
              ".WB_text",
              '[class*="Feed_body"]',
              ".card-feed .content p"
            ]);
            if (!desc) desc = meta("description");
          } else if (host.includes("mp.weixin.qq.com")) {
            title = textFrom(["#activity-name", "h1"]) || document.title;
            desc = textFrom(["#js_content"]);
            if (desc.length > 2e3) desc = desc.slice(0, 2e3);
          } else if (host.includes("kuaishou.com")) {
            title = textFrom([
              ".video-info-title",
              ".title",
              "h1"
            ]) || document.title;
            desc = textFrom([
              ".video-info-desc",
              ".desc",
              '[class*="caption"]'
            ]);
            if (!desc) desc = meta("description");
          } else if (host.includes("zhihu.com")) {
            title = textFrom([
              ".QuestionHeader-title",
              "h1.Post-Title",
              "h1"
            ]) || document.title;
            if (url.includes("/search")) {
              const items = [];
              document.querySelectorAll(".SearchResult-Card .content, .SearchResult-Card h2").forEach((el) => {
                const t = el.textContent?.trim();
                if (t && t.length > 5 && items.length < 10) items.push(t);
              });
              desc = items.join("\n\n");
              if (!desc) desc = meta("description");
            } else if (url.includes("/zvideo/") || url.includes("/video/")) {
              desc = meta("description");
            } else if (url.includes("/question/")) {
              const questionDesc = textFrom([".QuestionRichText", ".QuestionHeader-detail"]);
              const answer = textFrom([".AnswerItem .RichContent-inner", ".AnswerItem .RichText", ".RichContent-inner"]);
              const parts = [];
              if (questionDesc) parts.push(questionDesc);
              if (answer) parts.push(answer.slice(0, 2e3));
              desc = parts.join("\n\n");
              if (!desc) desc = meta("description");
            } else {
              desc = textFrom([
                ".Post-RichTextContainer",
                ".RichText",
                ".RichContent-inner"
              ]);
              if (desc.length > 2e3) desc = desc.slice(0, 2e3);
            }
          } else if (host.includes("toutiao.com")) {
            title = textFrom([
              ".article-title",
              "h1",
              ".title"
            ]) || document.title;
            desc = textFrom([
              ".article-content",
              ".article-detail"
            ]);
            if (!desc) desc = meta("description");
            if (desc.length > 2e3) desc = desc.slice(0, 2e3);
          } else if (host.includes("twitter.com") || host.includes("x.com")) {
            title = document.title;
            desc = meta("og:description") || meta("description");
          } else if (host.includes("linkedin.com")) {
            title = document.title;
            desc = meta("og:description") || meta("description");
          } else {
            title = document.title?.trim() ?? "";
            desc = meta("og:description") || meta("description");
            if (!desc) {
              const fallbackSelectors = [
                "article",
                '[role="main"]',
                "main",
                ".article-content",
                ".post-content"
              ];
              desc = textFrom(fallbackSelectors);
              if (desc.length > 2e3) desc = desc.slice(0, 2e3);
            }
          }
          title = (title || "").replace(/^\s*\(\d+\s*封私信\)\s*/g, "").replace(/^\s*\(\d+\s*条消息\)\s*/g, "").replace(/\s*[-_|–—]\s*(哔哩哔哩|bilibili|抖音|小红书|微博|快手|知乎|今日头条|Toutiao|搜索结果).*$/i, "").trim();
          if (!title) title = document.title?.trim() ?? "";
          if (!desc || desc.length < 10) {
            const fallbackDesc = meta("og:description") || meta("description");
            if (fallbackDesc && fallbackDesc.length > (desc?.length || 0)) {
              desc = fallbackDesc;
            }
          }
          if (title.length + (desc?.length || 0) < MIN_LEN) {
            const bodySelectors = [
              "article",
              '[role="main"]',
              "main",
              ".article-content",
              ".post-content",
              ".content",
              ".entry-content"
            ];
            const bodyText = textFrom(bodySelectors);
            if (bodyText.length > (desc?.length || 0)) {
              desc = bodyText.slice(0, 2e3);
            }
          }
          if (title.length + (desc?.length || 0) < MIN_LEN) {
            const bodyInner = document.body?.innerText?.trim() ?? "";
            if (bodyInner.length > 0) {
              desc = bodyInner.slice(0, 2e3);
            }
          }
          const combined = [title, desc].filter(Boolean).join("\n\n");
          const content = combined.slice(0, 5e3);
          return { content, valid: content.length >= MIN_LEN };
        }
      });
      if (result && typeof result === "object" && "content" in result) {
        const { content, valid } = result;
        extractedContent = content;
        contentValid = valid;
        if (contentValid) {
          contentPreview.textContent = extractedContent.slice(0, 120) + (extractedContent.length > 120 ? "..." : "");
          contentPreview.classList.remove("invalid");
          btnGenerate.disabled = false;
          contentActions.classList.remove("hidden");
          contentExpanded = false;
          btnToggleContent.textContent = "\u5C55\u5F00\u5168\u6587";
        } else {
          contentPreview.textContent = "\u9875\u9762\u5185\u5BB9\u4E0D\u8DB3 50 \u5B57\uFF0C\u8BF7\u624B\u52A8\u8F93\u5165\u5185\u5BB9\u540E\u751F\u6210";
          contentPreview.classList.add("invalid");
          btnGenerate.disabled = true;
        }
      }
    } catch (err) {
      contentPreview.textContent = "\u63D0\u53D6\u5931\u8D25\uFF1A" + err.message;
      contentPreview.classList.add("invalid");
    }
  }
  extractPageContent();
  btnGenerate.addEventListener("click", async () => {
    const platforms = Array.from(
      document.querySelectorAll(".platforms input:checked")
    ).map((el) => el.value);
    if (platforms.length === 0) {
      showError("\u8BF7\u81F3\u5C11\u9009\u62E9\u4E00\u4E2A\u5E73\u53F0");
      return;
    }
    hideError();
    btnGenerate.disabled = true;
    btnGenerate.textContent = "\u751F\u6210\u4E2D...";
    sectionResults.classList.add("hidden");
    try {
      const result = await generate({ content: extractedContent, platforms });
      renderResults(result.results);
      sectionResults.classList.remove("hidden");
    } catch (err) {
      showError(err.message);
    } finally {
      btnGenerate.disabled = !contentValid;
      btnGenerate.textContent = "\u751F\u6210\u6587\u6848";
    }
  });
  function renderResults(results) {
    resultsList.innerHTML = "";
    for (const [platform, output] of Object.entries(results)) {
      const name = PLATFORM_NAMES[platform] ?? platform;
      const text = typeof output === "string" ? output : output.content;
      const title = typeof output === "object" && output.title ? output.title : "";
      const displayText = title ? `${title}

${text}` : text;
      const item = document.createElement("div");
      item.className = "result-item";
      item.innerHTML = `
      <div class="result-header">
        <span class="result-platform">${name}</span>
        <button class="btn-copy" data-text="${encodeURIComponent(displayText)}">\u590D\u5236</button>
      </div>
      <div class="result-body">${escapeHtml(displayText)}</div>
    `;
      resultsList.appendChild(item);
    }
    resultsList.querySelectorAll(".btn-copy").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const text = decodeURIComponent(btn.dataset.text ?? "");
        await navigator.clipboard.writeText(text);
        btn.textContent = "\u5DF2\u590D\u5236";
        btn.classList.add("copied");
        setTimeout(() => {
          btn.textContent = "\u590D\u5236";
          btn.classList.remove("copied");
        }, 1500);
      });
    });
  }
  function showError(msg) {
    errorMsg.textContent = msg;
    errorMsg.classList.remove("hidden");
  }
  function hideError() {
    errorMsg.classList.add("hidden");
  }
  function escapeHtml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
})();
